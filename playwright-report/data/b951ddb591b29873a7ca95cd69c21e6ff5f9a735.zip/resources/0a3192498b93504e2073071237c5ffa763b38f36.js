(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__36b083e1._.css",
  "static/chunks/node_modules_1aba1400._.js",
  "static/chunks/_6f375f8a._.js"
],
    source: "dynamic"
});
